<?php

return [

    'code'                  => 'کۆد',
    'rate'                  => 'رێژە',
    'default'               => 'دراوی سەرەکی',
    'decimal_mark'          => 'شوێنی دەیی',
    'thousands_separator'   => 'جیاکەرەوەی هەزاران',
    'precision'             => 'وردی',
    'symbol' => [
        'symbol'            => 'هێما',
        'position'          => 'شوێنی هێما',
        'before'            => 'پێش بڕ',
        'after'             => 'دوای بڕی',
    ]

];
