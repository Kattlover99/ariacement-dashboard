<?php

return [

    'account_name'          => 'ناوی حیساب',
    'number'                => 'ژمارەی حیساب',
    'opening_balance'       => 'باڵانسی سەرەتا',
    'current_balance'       => 'باڵانسی ئێستا',
    'bank_name'             => 'ناوی بانک|سندوق',
    'bank_phone'            => 'ژمارەی بانک|سندوق',
    'bank_address'          => 'ناونیشانی بانک',
    'default_account'       => 'حیسابی سەرەکی',

];
