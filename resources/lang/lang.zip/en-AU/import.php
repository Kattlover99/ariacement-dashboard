<?php

return [

    'import'                => 'هێنان',
    'title'                 => 'هێنان :type',
    'message'               => 'فایلی رێگەپێدراو: XLS, XLSX. Please, <a target="_blank" href=":link"><strong>دوانلۆد</strong></a> نمونە.',

];
