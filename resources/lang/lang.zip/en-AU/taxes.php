<?php

return [

    'rate'                  => 'رێژە',
    'rate_percent'          => 'رێژە (%)',
    'normal'                => 'ئاسایی',
    'inclusive'             => 'دەگرێتەوە',
    'compound'              => 'ئاوێتە',
    'fixed'                 => 'جێگیرکراوە',
    'هەڵگرتن'           => 'Withholding',
];
