<?php

return [

    'sales_price' => 'نرخی فرۆشتن',
    'purchase_price' => 'نرخی کرین',

    'product_unit' => 'یەکە' ,
    'meter_square_header' => 'MP/KG',
    'meter_square' => 'مەتر٣',
    "ton" => "لیتر",
    "mp" => "مێگا پاسکال",
];
