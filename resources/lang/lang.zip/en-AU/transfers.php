<?php

return [

    'from_account'          => 'لەحیسابی',
    'to_account'            => 'بۆ حیسابی',

    'messages' => [
        'delete'            => ':لە بۆ :بۆ (:بڕە)',
    ],

];
