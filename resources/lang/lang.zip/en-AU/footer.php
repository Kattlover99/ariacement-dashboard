<?php

return [

    'version'               => 'ڤیرژنی',
    'powered'               => 'دروستکراوە لەلایەن صباح روبیتان',
    'link'                  => 'http://lass.technology/',
    'software'              => 'کارگەی کۆنکرێتی ئاریا',

];
