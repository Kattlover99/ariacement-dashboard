<?php

return [

    'rate'                  => 'المعدل',
    'rate_percent'          => 'المعدل (%)',
    'normal'                => 'عادي',
    'inclusive'             => 'شامل',
    'compound'              => 'مُركب',
    'fixed'                 => 'ثابت',
    'withholding'           => 'حجز',
];
