<?php

return [

    'previous'              => 'السابق',
    'next'                  => 'التالي',
    'showing'               => 'السجلات:first-:last of :total .',
    'page'                  => 'لكل صفحة.',

];
