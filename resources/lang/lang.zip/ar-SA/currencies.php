<?php

return [

    'code'                  => 'كود',
    'rate'                  => 'المعدل',
    'default'               => 'العملة الافتراضية',
    'decimal_mark'          => 'علامة عشرية',
    'thousands_separator'   => 'فاصل الآلاف',
    'precision'             => 'الدقة',
    'symbol' => [
        'symbol'            => 'الرمز',
        'position'          => 'مكان الرمز',
        'before'            => 'قبل القيمة',
        'after'             => 'بعد القيمة',
    ]

];
