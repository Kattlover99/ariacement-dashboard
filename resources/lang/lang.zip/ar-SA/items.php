<?php

return [

    'sales_price'           => 'سعر البيع',
    'purchase_price'        => 'سعر الشراء',

    'product_unit' => 'وحدة',
    'meter_square' => 'متر مربع',
    "ton" => "طن",
    "mp" => "م ف",
];
