<?php

return [

    'account_name'          => 'اسم الحساب',
    'number'                => 'الرقم',
    'opening_balance'       => 'الرصيد الافتتاحي',
    'current_balance'       => 'الرصيد الحالي',
    'bank_name'             => 'اسم البنك',
    'bank_phone'            => 'هاتف البنك',
    'bank_address'          => 'عنوان البنك',
    'default_account'       => 'الحساب الافتراضي',

];
