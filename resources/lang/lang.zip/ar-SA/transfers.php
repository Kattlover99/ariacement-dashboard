<?php

return [

    'from_account'          => 'من حساب',
    'to_account'            => 'إلى حساب',

    'messages' => [
        'delete'            => ':from إلى :to (:amount)',
    ],

];
