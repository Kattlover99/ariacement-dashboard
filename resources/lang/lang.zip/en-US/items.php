<?php

return [

    'sales_price' => 'Sale Price',
    'purchase_price' => 'Purchase Price',
    'product_unit' => 'Unit',
    'meter_square' => 'Meter Square',
    "ton" => "Ton",
    "mp" => "MP",
];
