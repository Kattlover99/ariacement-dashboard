<?php

return [

    'code'                  => 'Code',
    'rate'                  => 'Rate',
    'default'               => 'Default Currency',
    'decimal_mark'          => 'Decimal Place',
    'thousands_separator'   => 'Thousands Separator',
    'precision'             => 'Precision',
    'symbol' => [
        'symbol'            => 'Symbol',
        'position'          => 'Symbol Position',
        'before'            => 'Before Amount',
        'after'             => 'After Amount',
    ]

];
