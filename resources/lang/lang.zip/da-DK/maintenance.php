<?php

return [

    'title' => 'Under Vedligeholdelse',

    'message' => 'Beklager, Vi er nede for vedligeholdelse. Prøv venligst senere!',

];
