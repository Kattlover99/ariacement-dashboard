<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Seneste login',
        'paid_at'           => 'Betalingsdato',
        'started_at'        => 'Startdato',
        'ended_at'          => 'Slutdato',
        'billed_at'         => 'Regningsdato',
        'due_at'            => 'Forfaldsdato',
        'invoiced_at'       => 'Fakturadato',
        'issued_at'         => 'Udstedelsesdato',
        'symbol_first'      => 'Symbolplacering',
        'reconciled'        => 'Afstemt',
        'expense_account'   => 'Fra konto',
        'income_account'    => 'Til konto',
    ],

];
