<?php

return [

    'import'                => 'Importer',
    'title'                 => 'Importer :type',
    'message'               => 'Tilladte filtyper: CSV, XLS. Venligst, <a target="_blank" href=":link"><strong>download</strong></a> eksempelfilen.',

];
