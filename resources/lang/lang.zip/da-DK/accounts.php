<?php

return [

    'account_name'          => 'Kontonavn',
    'number'                => 'Nummer',
    'opening_balance'       => 'Åbningsbalance',
    'current_balance'       => 'Nuværende saldo',
    'bank_name'             => 'Banknavn',
    'bank_phone'            => 'Telefon bank',
    'bank_address'          => 'Bank adresse',
    'default_account'       => 'Standardkonto',

];
