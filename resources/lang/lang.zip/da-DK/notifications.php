<?php

return [

    'whoops'              => 'Ups!',
    'hello'               => 'Hallo!',
    'salutation'          => 'Med venlig hilsen,<br> : company_name',
    'subcopy'             => 'Hvis du har problemer med at klikke på ":text" knappen, kopier og indsæt Webadressen nedenfor i din browser: [: url](:url)',

];
