<?php

return [

    'reconcile'             => 'Afstem',
    'unreconcile'           => 'Uafsem',
    'reconciled'            => 'Afstemt',
    'opening_balance'       => 'Åbningsbalance',
    'closing_balance'       => 'Primo saldo',
    'unreconciled'          => 'Uafstemt',
    'transactions'          => 'Transaktioner',
    'start_date'            => 'Start dato',
    'end_date'              => 'Slut dato',
    'cleared_amount'        => 'Afstemt beløb',
    'deposit'               => 'Indbetal',
    'withdrawal'            => 'Udbetaling',

];
