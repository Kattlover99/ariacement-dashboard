<?php

return [

    'from_account'          => 'Fra konto',
    'to_account'            => 'Til konto',

    'messages' => [
        'delete'            => ':from til :to (:amount)',
    ],

];
