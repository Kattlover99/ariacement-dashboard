<?php

return [

    'code'                  => 'Kode',
    'rate'                  => 'Sats',
    'default'               => 'Standardvaluta',
    'decimal_mark'          => 'Decimaltegn',
    'thousands_separator'   => 'Tusindetalsseparator',
    'precision'             => 'Præcision',
    'conversion'            => 'Valutakonvertering: :price (:currency_code) til :currency_rate',
    'symbol' => [
        'symbol'            => 'Symbol',
        'position'          => 'Symbol position',
        'before'            => 'Før beløbet',
        'after'             => 'Efter beløb',
    ]

];
