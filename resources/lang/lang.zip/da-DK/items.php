<?php

return [

    'sales_price'            => 'Salgspris',
    'purchase_price'         => 'Købspris',
    'enter_item_description' => 'Indtast varebeskrivelsen',

];
