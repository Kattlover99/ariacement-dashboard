<?php

return [

    'whoops'              => 'Vaya!',
    'hello'               => 'Hola!',
    'salutation'          => 'Saludos,<br> :company_name',
    'subcopy'             => 'Si tiene problemas haciendo clic en el boton “:text”, copie y pegue la dirección URL en su navegador: [:url] (:url)',

];
