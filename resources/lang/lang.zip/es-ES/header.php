<?php

return [

    'change_language'       => 'Cambiar idioma',
    'last_login'            => 'Último ingreso :time',
    'notifications' => [
        'counter'           => '{0} No tiene notificaciones |{1} Tiene :count notificación | [2,*] Tiene :count notificaciones',
        'overdue_invoices'  => '{1} :count factura vencida | [2,*] :count facturas vencidas',
        'upcoming_bills'    => '{1} :count recibo por vencer|[2,*] :count recibos por vencer',
        'view_all'          => 'Ver todas'
    ],
    'docs_link'             => 'https://akaunting.com/docs',
    'support_link'          => 'https://akaunting.com/support',

];
