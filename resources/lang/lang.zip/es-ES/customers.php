<?php

return [

    'can_login'             => '¿Puede iniciar sesión?',
    'user_created'          => 'Usuario Creado',

    'error' => [
        'email'             => 'Ese email ya está en uso.',
    ],

];
