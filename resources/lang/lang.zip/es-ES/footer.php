<?php

return [

    'version'               => 'Versión',
    'powered'               => 'Powered By Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Software de Contabilidad Libre',

];
