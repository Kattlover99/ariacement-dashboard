<?php

return [

    'sales_price'           => 'Precio de Venta',
    'purchase_price'        => 'Precio de Compra',

];
