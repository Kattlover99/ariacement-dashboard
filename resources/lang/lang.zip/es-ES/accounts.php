<?php

return [

    'account_name'          => 'Nombre de Cuenta',
    'number'                => 'Número',
    'opening_balance'       => 'Saldo de apertura',
    'current_balance'       => 'Saldo actual',
    'bank_name'             => 'Nombre del Banco',
    'bank_phone'            => 'Teléfono Banco',
    'bank_address'          => 'Dirección del Banco',
    'default_account'       => 'Cuenta Predeterminada',

];
