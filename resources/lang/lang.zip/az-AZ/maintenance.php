<?php

return [

    'title' => 'Texniki işlər gedir',

    'message' => 'Üzr istəyirik, texniki işlərlə əlaqədar bağlanmışıq. Zəhmət olmasa daha sonra yenə cəhd edin!',

];
