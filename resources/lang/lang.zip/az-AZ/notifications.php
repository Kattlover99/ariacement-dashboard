<?php

return [

    'whoops'              => 'Ayyy səni!',
    'hello'               => 'Salam!',
    'salutation'          => 'Hörmətlə,<br> :company_name',
    'subcopy'             => '":text" düyməyə vura bilmirsinizsə, aşaöıdakı linki kopyalayib browserə köçürün: [:url](:url)',

];
