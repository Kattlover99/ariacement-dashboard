<?php

return [

    'domain'                => 'Domain Adı',
    'logo'                  => 'Logo',

    'error' => [
        'not_user_company'  => 'Xəta: Bu şirkəti dəyişdirmə icazəniz yoxdur!',
        'delete_active'     => 'Xəta: Mövcud şirkəti silə bilməzsiniz. Zəhmət olmazsa, əvvəlcə başqa bir şirkətə keçin!',
        'disable_active'    => 'Xəta: Mövcud şirkəti deaktiv edə bilməzsiniz. Zəhmət olmazsa, əvvəlcə başqa bir şirkətə keçin!',
    ],

];
