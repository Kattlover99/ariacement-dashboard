<?php

return [

    'import'                => 'İdxal et',
    'title'                 => ':type İdxal et',
    'message'               => 'İcazə veriəln fayl tipləri: XLS, XLSX. Lütfen, örnek dosyayı <a target="_blank" href=":link"><strong>indirin</strong></a>.',

];
