<?php

return [

    'code'                  => 'Kod',
    'rate'                  => 'Məzənnə',
    'default'               => 'Varsayılan Valyuta',
    'decimal_mark'          => 'Onluq Ayırıcı',
    'thousands_separator'   => 'Minlik Aıyrıcı',
    'precision'             => 'Dəqiqlik',
    'conversion'            => 'Valyuta konversiyası',
    'symbol' => [
        'symbol'            => 'İşarə',
        'position'          => 'İşarənin Yeri',
        'before'            => 'Məbləğdən Əvvəl',
        'after'             => 'Məbləğdən Sonra',
    ]

];
