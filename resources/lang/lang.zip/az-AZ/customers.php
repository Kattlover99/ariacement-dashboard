<?php

return [

    'can_login'             => 'Giriş Edə Bilər',
    'user_created'          => 'İstifadəçi yarat',

    'error' => [
        'email'             => 'E-poçt ünvanı istifadə edilir.',
    ],

];
