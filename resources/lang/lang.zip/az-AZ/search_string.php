<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Son Giriş',
        'paid_at'           => 'Ödəniş Tarixi',
        'started_at'        => 'Başlanğıc Tarixi',
        'ended_at'          => 'Bitiş Tarixi',
        'billed_at'         => 'Faktura Tarixi',
        'due_at'            => 'Son Tarix',
        'invoiced_at'       => 'Faktura Tarixi',
        'issued_at'         => 'Əməliyyat Tarixi',
        'symbol_first'      => 'İşarə Yeri',
        'reconciled'        => 'Razılaşdırıldı',
        'expense_account'   => 'Göndərən Hesab',
        'income_account'    => 'Qəbul Edən Hesab',
    ],

];
