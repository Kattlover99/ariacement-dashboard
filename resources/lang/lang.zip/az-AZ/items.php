<?php

return [

    'sales_price'           => 'Satış Qiyməti',
    'purchase_price'        => 'Alış Qiyməti',

];
