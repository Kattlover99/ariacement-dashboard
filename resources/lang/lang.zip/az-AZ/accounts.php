<?php

return [

    'account_name'          => 'Hesab Adı',
    'number'                => 'Nömrə',
    'opening_balance'       => 'Açılış Balansı',
    'current_balance'       => 'Mövcud Balans',
    'bank_name'             => 'Bank Adı',
    'bank_phone'            => 'Bank Telefonu',
    'bank_address'          => 'Bank Ünvanı',
    'default_account'       => 'Varsayılan Hesab',

];
