<?php

return [

    'rate'                  => 'হার',
    'rate_percent'          => 'হার (%)',
    'normal'                => 'সাধারণ ',
    'inclusive'             => 'অন্তর্ভুক্তি',
    'compound'              => 'যৌগিক',
    'fixed'                 => 'স্থায়ী',
    'withholding'           => 'আটকে যাওয়া',
];
