<?php

return [

    'version'               => 'সংস্করণ',
    'powered'               => 'অ্যাকাউন্টিং(Akaunting) দ্বারা চালিত',
    'link'                  => 'https://akaunting.com',
    'software'              => 'মুক্ত হিসাবরক্ষণ সফটওয়্যার',

];
