<?php

return [

    'from_account'          => 'একাউন্ট হতে ',
    'to_account'            => 'একাউন্টে ',

    'messages' => [
        'delete'            => ':from থেকে :to (:amount)',
    ],

];
