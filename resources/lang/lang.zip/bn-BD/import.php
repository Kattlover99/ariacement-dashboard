<?php

return [

    'import'                => 'ইমপোর্ট',
    'title'                 => 'ইমপোর্ট :type',
    'message'               => 'অনুমোদিত ফাইলের ধরণসমূহ হলোঃ XLS, XLSX । দয়া করে নমুনা ফাইল <a target="_blank" href=":link"><strong> ডাউনলোড </strong></a> করুন।',

];
