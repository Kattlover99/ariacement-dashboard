<?php

return [

    'recurring'             => 'Ponavljajuće',
    'every'                 => 'Svakih',
    'period'                => 'Razdoblje',
    'times'                 => 'Puta',
    'daily'                 => 'Dnevno',
    'weekly'                => 'Sedmično',
    'monthly'               => 'Mjesečno',
    'yearly'                => 'Godišnje',
    'custom'                => 'Prilagođeno',
    'days'                  => 'Dan(a)',
    'weeks'                 => 'Sedmice(a)',
    'months'                => 'Mjesec(i)',
    'years'                 => 'Godine(a)',
    'message'               => 'Ovo je ponavljajući :type i sljedeći :type će automatski biti generiran :date',

];
