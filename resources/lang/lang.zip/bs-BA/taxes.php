<?php

return [

    'rate'                  => 'Stopa',
    'rate_percent'          => 'Stopa (%)',
    'normal'                => 'Normalno',
    'inclusive'             => 'Uključivo',
    'compound'              => 'Veza',
    'fixed'                 => 'Fiksno',
    'withholding'           => 'Zadržavajuće',
];
