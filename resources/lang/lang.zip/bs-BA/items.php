<?php

return [

    'sales_price'            => 'Prodajna cijena',
    'purchase_price'         => 'Kupovna cijena',
    'enter_item_description' => 'Unesite opis stavke',

];
