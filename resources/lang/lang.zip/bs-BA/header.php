<?php

return [

    'change_language'       => 'Promjena jezika',
    'last_login'            => 'Zadnja prijava :time',
    'notifications' => [
        'counter'           => '{0} Nemate obavijesti|{1} Imate :count obavijest | [2,*] Imate :count obavijesti',
        'overdue_invoices'  => '{1} :count dospjela faktura|[2,*] :count dospjelih faktura',
        'upcoming_bills'    => '{1} :count nadolazeći račun|[2,*] :count nadolazećih računa',
        'view_all'          => 'Vidi sve'
    ],
    'docs_link'             => 'https://akaunting.com/docs',
    'support_link'          => 'https://akaunting.com/support',

];
