<?php

return [

    'version'               => 'Verzija',
    'powered'               => 'Omogućeno od Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Besplatan web finansijski softver',

];
