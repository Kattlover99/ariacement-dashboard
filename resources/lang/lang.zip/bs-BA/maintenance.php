<?php

return [

    'title' => 'Pod održavanjem',

    'message' => 'Žao nam je, trenutno smo na održavanju. Molimo pokušajte ponovo kasnije!',

];
