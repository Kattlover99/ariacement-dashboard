<?php

return [

    'previous'              => 'Prethodna',
    'next'                  => 'Sljedeća',
    'showing'               => ':first-:last od :total unosa..',
    'page'                  => 'po stranici.',

];
