<?php

return [

    'code'                  => 'Код',
    'rate'                  => 'Курс',
    'default'               => 'Валута по подразбиране',
    'decimal_mark'          => 'Десетичен знак',
    'thousands_separator'   => 'Разделител за хилядни',
    'precision'             => 'Точност',
    'symbol' => [
        'symbol'            => 'Символ',
        'position'          => 'Символ позиция',
        'before'            => 'Преди сума',
        'after'             => 'След сума',
    ]

];
