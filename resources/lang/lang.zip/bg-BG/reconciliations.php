<?php

return [

    'reconcile'             => 'Консолидация',
    'unreconcile'           => 'Деконсолидация',
    'reconciled'            => 'Оспорен',
    'opening_balance'       => 'Начално салдо',
    'closing_balance'       => 'Краен Баланс',
    'unreconciled'          => 'Не подлежи на оспорване',
    'transactions'          => 'Плащания',
    'start_date'            => 'Начална дата',
    'end_date'              => 'Крайна дата',
    'cleared_amount'        => 'Изчистена Сума',
    'deposit'               => 'Депозит',
    'withdrawal'            => 'Теглене',

];
