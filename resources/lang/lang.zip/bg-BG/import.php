<?php

return [

    'import'                => 'Импортиране',
    'title'                 => 'Импортиране :type',
    'message'               => 'Разрешени формати: CSV, XLS. Моля, <a target="_blank" href=":link"><strong>изтегли</strong></a> примерен файл.',

];
