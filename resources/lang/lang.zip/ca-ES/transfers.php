<?php

return [

    'from_account'          => 'Compte origen',
    'to_account'            => 'Compte destí',

    'messages' => [
        'delete'            => ':from a :to (:amount)',
    ],

];
