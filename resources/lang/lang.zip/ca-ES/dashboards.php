<?php

return [

    'error' => [
        'not_user_dashboard'    => 'Error: No tens permisos per canviar aquest tauler!',
        'delete_last'           => 'Error: No es pot esborrar el darrer tauler. Si us plau, crea\'n un de nou primer!',
        'disable_last'          => 'Error: No es pot desactivar el darrer tauler. Si us plau, crea\'n un de nou primer!',
    ],

];
