<?php

return [

    'can_login'             => 'Pots iniciar?',
    'user_created'          => 'S\'ha creat l\'usuari',

    'error' => [
        'email'             => 'El correu electrònic proporcionat ja existeix',
    ],

];
