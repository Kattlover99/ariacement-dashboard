<?php

return [

    'installed_version'     => 'Versió instal·lada',
    'latest_version'        => 'Última Versió',
    'update'                => 'Actualitza Akaunting a la versió :version',
    'changelog'             => 'Historial de canvis',
    'check'                 => 'Comprova',
    'new_core'              => 'Hi ha disponible una nova versió d\'Akaunting',
    'latest_core'           => 'Enhorabona! Tens instal·lada l\'última versió d\'Akaunting. Les futures actualitzacions de seguretat s\'aplicaran automàticament.',
    'success'               => 'El procés d\'actualització s\'ha completat satisfactòriament.',
    'error'                 => 'El procés d\'actualització ha fallat. Si us plau, torna a provar-ho.',

];
