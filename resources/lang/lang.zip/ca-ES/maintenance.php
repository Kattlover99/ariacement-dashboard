<?php

return [

    'title' => 'En manteniment',

    'message' => 'Disculpa, estem fent tasques de manteniment. Si us plau, torna a intentar-ho més tard!',

];
