<?php

return [

    'sales_price'            => 'Preu de venda',
    'purchase_price'         => 'Preu de compra',
    'enter_item_description' => 'Introdueix la descripció de l\'article',

];
