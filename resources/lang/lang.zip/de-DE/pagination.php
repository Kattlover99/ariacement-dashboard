<?php

return [

    'previous'              => 'Vorherige',
    'next'                  => 'Nächste',
    'showing'               => ':first :last von :total Datensätze.',
    'page'                  => 'pro Seite.',

];
