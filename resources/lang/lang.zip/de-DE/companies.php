<?php

return [

    'domain'                => 'Domain',
    'logo'                  => 'Logo',

    'error' => [
        'not_user_company'  => 'Fehler: Sie haben keine Berechtigung, die Firmendaten zu ändern!',
        'delete_active'     => 'Fehler: Das aktive Unternehmen kann nicht gelöscht werden. Bitte zunächst das Unternehmen wechseln!',
        'disable_active'    => 'Fehler: Das aktive Unternehmen kann nicht deaktiviert werden. Bitte zunächst das Unternehmen wechseln!',
    ],

];
