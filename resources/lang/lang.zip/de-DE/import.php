<?php

return [

    'import'                => 'Importieren',
    'title'                 => ':type importieren',
    'message'               => 'Erlaubte Datei-Typen: XLS, XLSX. Bitte, <a target="_blank" href=":link"><strong>hier</strong></a> die Beispieldatei herunterladen.',

];
