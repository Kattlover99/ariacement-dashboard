<?php

return [

    'can_login'             => 'Login erlauben?',
    'user_created'          => 'Benutzer angelegt',

    'error' => [
        'email'             => 'Diese Email ist bereits in Benutzung.',
    ],

];
