<?php

return [

    'sales_price'            => 'Verkaufspreis',
    'purchase_price'         => 'Einkaufspreis',
    'enter_item_description' => 'Artikelbeschreibung eingeben',

];
