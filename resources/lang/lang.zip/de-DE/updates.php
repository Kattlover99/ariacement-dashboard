<?php

return [

    'installed_version'     => 'Installierte Version',
    'latest_version'        => 'Neueste Version',
    'update'                => 'Akaunting auf Version :version updaten',
    'changelog'             => 'Changelog',
    'check'                 => 'Prüfen',
    'new_core'              => 'Eine aktualisierte Version von Akaunting ist verfügbar.',
    'latest_core'           => 'Glückwunsch! Sie nutzen die aktuellste Version von Akaunting. Zukünftige Sicherheitsupdates werden automatisch angewendet.',
    'success'               => 'Der Updateprozess wurde erfolgreich ausgeführt.',
    'error'                 => 'Updateprozess fehlgeschlagen, bitte erneut versuchen.',

];
