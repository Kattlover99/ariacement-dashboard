<?php

return [

    'error' => [
        'not_user_dashboard'    => 'Error: You are not allowed to change this dashboard!',
        'delete_last'           => 'Error: Can not delete the last dashboard. Please, create a new one first!',
        'disable_last'          => 'Error: Can not disable the last dashboard. Please, create a new one first!',
    ],

];
