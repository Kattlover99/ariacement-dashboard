<?php

return [

    'previous'              => 'Previous',
    'next'                  => 'Next',
    'showing'               => ':first-:last of :total records.',
    'page'                  => 'per page.',

];
