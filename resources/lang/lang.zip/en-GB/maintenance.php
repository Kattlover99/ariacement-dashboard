<?php

return [

    'title' => 'Under Maintenance',

    'message' => 'Sorry, we\'re down for maintenance. Please, try again later!',

];
