<?php

return [

    'title'     => 'Title',
    'unit'      => 'Unit',
];
