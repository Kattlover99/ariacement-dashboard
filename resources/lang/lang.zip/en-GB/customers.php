<?php

return [

    'can_login'             => 'Can Login?',
    'user_created'          => 'User Created',

    'error' => [
        'email'             => 'The email has already been taken.',
    ],

];
