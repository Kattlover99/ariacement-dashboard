<?php

return [

    'rate'                  => 'Rate',
    'rate_percent'          => 'Rate (%)',
    'normal'                => 'Normal',
    'inclusive'             => 'Inclusive',
    'compound'              => 'Compound',
    'fixed'                 => 'Fixed',
    'withholding'           => 'Withholding',
];
