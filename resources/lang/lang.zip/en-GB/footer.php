<?php

return [

    'version'               => 'Version',
    'powered'               => 'Powered By Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Free Accounting Software',

];
