<?php

return [

    'reconcile'             => 'Reconcile',
    'unreconcile'           => 'Unreconcile',
    'reconciled'            => 'Reconciled',
    'opening_balance'       => 'Opening Balance',
    'closing_balance'       => 'Closing Balance',
    'unreconciled'          => 'Unreconciled',
    'transactions'          => 'Transactions',
    'start_date'            => 'Start Date',
    'end_date'              => 'End Date',
    'cleared_amount'        => 'Cleared Amount',
    'deposit'               => 'Deposit',
    'withdrawal'            => 'Withdrawal',

];
