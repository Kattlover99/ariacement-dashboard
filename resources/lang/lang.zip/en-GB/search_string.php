<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Last Login',
        'paid_at'           => 'Paid Date',
        'started_at'        => 'Started Date',
        'ended_at'          => 'Ended Date',
        'billed_at'         => 'Bill Date',
        'due_at'            => 'Due Date',
        'invoiced_at'       => 'Invoice Date',
        'issued_at'         => 'Issue Date',
        'symbol_first'      => 'Symbol Position',
        'reconciled'        => 'Reconciled',
        'expense_account'   => 'From Account',
        'income_account'    => 'To Account',
    ],

];
