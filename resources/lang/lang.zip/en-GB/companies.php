<?php

return [

    'domain'                => 'Domain',
    'logo'                  => 'Logo',

    'error' => [
        'not_user_company'  => 'Error: You are not allowed to change this company!',
        'delete_active'     => 'Error: Can not delete the active company. Please, switch to another first!',
        'disable_active'    => 'Error: Can not disable the active company. Please, switch to another first!',
    ],

];
