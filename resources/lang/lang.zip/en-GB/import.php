<?php

return [

    'import'                => 'Import',
    'title'                 => 'Import :type',
    'message'               => 'Allowed file types: XLS, XLSX. Please, <a target="_blank" href=":link"><strong>download</strong></a> the sample file.',

];
