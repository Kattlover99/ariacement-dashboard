<?php

return [

    'from_account'          => 'From Account',
    'to_account'            => 'To Account',

    'messages' => [
        'delete'            => ':from to :to (:amount)',
    ],

];
