<?php

return [

    'sales_price'               => 'Sale Price',
    'purchase_price'            => 'Purchase Price',
    'enter_item_description'    => 'Enter item description',

    'product_unit' => 'Unit',
    'meter_square_header' => 'Meter Square',
    'meter_square' => 'Meter Square',
    "ton" => "Ton",
    "mp" => "MP",
];
