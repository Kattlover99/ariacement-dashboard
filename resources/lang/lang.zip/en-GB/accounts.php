<?php

return [

    'account_name'          => 'Account Name',
    'number'                => 'Number',
    'opening_balance'       => 'Opening Balance',
    'current_balance'       => 'Current Balance',
    'bank_name'             => 'Bank Name',
    'bank_phone'            => 'Bank Phone',
    'bank_address'          => 'Bank Address',
    'default_account'       => 'Default Account',

];
