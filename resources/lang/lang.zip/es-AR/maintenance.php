<?php

return [

    'title' => 'En Mantenimiento',

    'message' => 'Lo sentimos, estamos en mantenimiento. Por favor, inténtalo de nuevo más tarde!',

];
