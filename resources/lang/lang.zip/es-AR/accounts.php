<?php

return [

    'account_name'          => 'Nombre de cuenta',
    'number'                => 'Número',
    'opening_balance'       => 'Saldo de apertura',
    'current_balance'       => 'Saldo actual',
    'bank_name'             => 'Nombre del banco',
    'bank_phone'            => 'Teléfono del banco',
    'bank_address'          => 'Dirección del banco',
    'default_account'       => 'Cuenta predeterminada',

];
