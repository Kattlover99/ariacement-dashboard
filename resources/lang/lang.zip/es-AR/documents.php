<?php

return [
    'messages' => [
        'email_sent'        => '¡El correo electrónico de la factura ha sido enviado!',
        'marked_sent'       => '¡Factura marcada como enviada!',
        'marked_paid'       => '¡Factura marcada como pagada!',
        'marked_viewed'     => '¡Factura marcada como vista!',
        'marked_cancelled'  => '¡Factura marcada como cancelada!',
        'marked_received'   => '¡Factura marcada como recibida!',
    ],
];
