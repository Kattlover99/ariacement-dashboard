<?php

return [

    'import'                => 'Importar',
    'title'                 => 'Importar :type',
    'message'               => 'Formatos permitidos: XLS, XLSX. Por favor, <a target="_blank" href=":link"> <strong>descargue</strong></a> el archivo de ejemplo.',

];
