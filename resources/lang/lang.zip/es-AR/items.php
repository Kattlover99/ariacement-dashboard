<?php

return [

    'sales_price'           => 'Precio de venta',
    'purchase_price'        => 'Precio de compra',

];
