<?php

return [

    'installed_version'     => 'Versión instalada',
    'latest_version'        => 'Última versión',
    'update'                => 'Actualizar Akaunting a versión :version',
    'changelog'             => 'Historial de cambios',
    'check'                 => 'Comprobar',
    'new_core'              => 'Una versión actualizada de Akaunting está disponible.',
    'latest_core'           => '¡Felicidades! Tienes la última versión de Akaunting. Las actualizaciones de seguridad futuras se aplicarán automáticamente.',
    'success'               => 'El proceso de actualización se ha completado con éxito.',
    'error'                 => 'El proceso de actualización ha fallado, por favor inténtelo de nuevo.',

];
