<?php

return [

    'can_login'             => '¿Puede iniciar sesión?',
    'user_created'          => 'Usuario creado',

    'error' => [
        'email'             => 'El correo electrónico ya está en uso.',
    ],

];
