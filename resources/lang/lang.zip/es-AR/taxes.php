<?php

return [

    'rate'                  => 'Tasa',
    'rate_percent'          => 'Tasa (%)',
    'normal'                => 'Normal',
    'inclusive'             => 'Incluido',
    'compound'              => 'Compuesto',
    'fixed'                 => 'Fijo',
    'withholding'           => 'Retención',
];
