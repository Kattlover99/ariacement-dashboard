<?php

return [

    'previous'              => 'Anterior',
    'next'                  => 'Siguiente',
    'showing'               => ':first-:last de :total registros.',
    'page'                  => 'por página.',

];
