<?php

return [

    'reconcile'             => 'Conciliar',
    'unreconcile'           => 'Revertir conciliación',
    'reconciled'            => 'Conciliado',
    'opening_balance'       => 'Saldo de apertura',
    'closing_balance'       => 'Saldo de cierre',
    'unreconciled'          => 'Sin conciliar',
    'transactions'          => 'Transacciones',
    'start_date'            => 'Fecha de inicio',
    'end_date'              => 'Fecha de fin',
    'cleared_amount'        => 'Monto',
    'deposit'               => 'Depósito',
    'withdrawal'            => 'Retiro',

];
