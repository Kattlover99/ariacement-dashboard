<?php

return [

    'recurring'             => 'Repetitivo',
    'every'                 => 'Cada',
    'period'                => 'Período',
    'times'                 => 'Veces',
    'daily'                 => 'Diario',
    'weekly'                => 'Semanal',
    'monthly'               => 'Mensual',
    'yearly'                => 'Anual',
    'custom'                => 'Personalizado',
    'days'                  => 'Día(s)',
    'weeks'                 => 'Semana(s)',
    'months'                => 'Mes(es)',
    'years'                 => 'Año(s)',
    'message'               => 'Éste es un :type periódico y el siguiente :type se generará automáticamente el día :date',

];
