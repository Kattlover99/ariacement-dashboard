<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Último acceso',
        'paid_at'           => 'Fecha de pago',
        'started_at'        => 'Fecha de inicio',
        'ended_at'          => 'Fecha de fin',
        'billed_at'         => 'Fecha de factura',
        'due_at'            => 'Fecha de vencimiento',
        'invoiced_at'       => 'Fecha de factura',
    ],

];
