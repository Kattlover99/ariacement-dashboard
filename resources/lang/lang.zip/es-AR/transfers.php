<?php

return [

    'from_account'          => 'De cuenta',
    'to_account'            => 'A cuenta',

    'messages' => [
        'delete'            => ':de a :to (:amount)',
    ],

];
