<?php

return [

    'reconcile'             => 'Σύγκριση',
    'reconciled'            => 'Σε συμφωνία',
    'closing_balance'       => 'Υπόλοιπο κλεισίματος',
    'unreconciled'          => 'Σε ασυμφωνία',
    'transactions'          => 'Συναλλαγές',
    'start_date'            => 'Ημερομηνία Έναρξης',
    'end_date'              => 'Ημερομηνία Λήξης',
    'cleared_amount'        => 'Εκκαθαρισμένο Υπόλοιπο',
    'deposit'               => 'Κατάθεση',
    'withdrawal'            => 'Ανάληψη',

];
