<?php

return [

    'from_account'          => 'Από λογαριασμό',
    'to_account'            => 'Προς λογαριασμό',

    'messages' => [
        'delete'            => ':from προς :to (:amount)',
    ],

];
