<?php

return [

    'previous'              => '&laquo; Προηγούμενη',
    'next'                  => 'Επόμενη &raquo;',
    'showing'               => ':first-:last από :total εγγραφές.',
    'page'                  => 'ανά σελίδα.',

];
