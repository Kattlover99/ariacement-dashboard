<?php

return [

    'rate'                  => 'Συντελεστής',
    'rate_percent'          => 'Συντελεστής (%)',
    'normal'                => 'Κανονικός',
    'inclusive'             => 'Συμπεριλαμβανόμενος',
    'compound'              => 'Μεικτός',
    'fixed'                 => 'Πάγιο',
    'withholding'           => 'Κρατήσεις',
];
