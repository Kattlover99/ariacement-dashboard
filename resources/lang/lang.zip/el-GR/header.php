<?php

return [

    'change_language'       => 'Αλλαγή γλώσσας',
    'last_login'            => 'Τελευταία είσοδος :time',
    'notifications' => [
        'counter'           => '{0} Δεν έχετε καμία ειδοποίηση |{1} Έχετε :count ειδοποίηση| [2 *] Έχετε :count ειδοποιήσεις',
        'overdue_invoices'  => '{1} :count εκπρόθεσμο τιμολόγιο | [2 *] :count εκπρόθεσμα τιμολόγια',
        'upcoming_bills'    => '{1} :count επερχόμενος λογαριασμός | [2 *] :count επερχόμενοι λογαριασμοί',
        'view_all'          => 'Προβολή Όλων'
    ],
    'docs_link'             => 'https://akaunting.com/docs',
    'support_link'          => 'https://akaunting.com/support',

];
