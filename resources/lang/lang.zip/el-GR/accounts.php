<?php

return [

    'account_name'          => 'Όνομα Λογαριασμού',
    'number'                => 'Αριθμός',
    'opening_balance'       => 'Εναρκτήριο υπόλοιπο',
    'current_balance'       => 'Τρέχον υπόλοιπο',
    'bank_name'             => 'Όνομα τράπεζας',
    'bank_phone'            => 'Τηλέφωνο τράπεζας',
    'bank_address'          => 'Διεύθυνση τράπεζας',
    'default_account'       => 'Προεπιλεγμένος λογαριασμός',

];
