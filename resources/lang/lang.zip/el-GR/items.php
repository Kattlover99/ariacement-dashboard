<?php

return [

    'sales_price'           => 'Τιμή Πώλησης',
    'purchase_price'        => 'Τιμή αγοράς',

];
