<?php

return [

    'version'               => 'Verze',
    'powered'               => 'Powered By Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Účetní software zdarma',

];
