<?php

return [

    'previous'              => '&laquo; předchozí',
    'next'                  => 'další &raquo;',
    'showing'               => ':first-:last z :total záznamů.',
    'page'                  => 'na stránku.',

];
