<?php

return [

    'title' => 'Režim údržby',

    'message' => 'Právě pracujeme na stránkách, zkuste to prosím později!',

];
