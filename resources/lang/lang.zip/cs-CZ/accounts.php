<?php

return [

    'account_name'          => 'Název účtu',
    'number'                => 'Číslo',
    'opening_balance'       => 'Počáteční zůstatek',
    'current_balance'       => 'Aktuální zůstatek',
    'bank_name'             => 'Název banky',
    'bank_phone'            => 'Telefon do banky',
    'bank_address'          => 'Adresa banky',
    'default_account'       => 'Výchozí účet',

];
