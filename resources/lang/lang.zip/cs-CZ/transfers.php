<?php

return [

    'from_account'          => 'Z účtu',
    'to_account'            => 'Na účet',

    'messages' => [
        'delete'            => ':from na :to (:amount)',
    ],

];
