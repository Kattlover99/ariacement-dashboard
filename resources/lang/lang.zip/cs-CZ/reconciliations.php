<?php

return [

    'reconcile'             => 'Vyrovnat',
    'unreconcile'           => 'Nevyrovnáno',
    'reconciled'            => 'Vyrovnáno',
    'opening_balance'       => 'Počáteční zůstatek',
    'closing_balance'       => 'Konečný zůstatek',
    'unreconciled'          => 'Nevyrovnáno',
    'transactions'          => 'Platby',
    'start_date'            => 'Počáteční datum',
    'end_date'              => 'Koncové datum',
    'cleared_amount'        => 'Zaúčtovaná částka',
    'deposit'               => 'Vklad',
    'withdrawal'            => 'Výběr',

];
