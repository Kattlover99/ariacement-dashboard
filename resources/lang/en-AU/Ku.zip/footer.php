<?php

return [

    'version'               => 'ڤیرژنی',
    'powered'               => 'دروستکراوە لەلایەن صباح روبیتان',
    'link'                  => 'http://lass.technology/',
    'software'              => 'سیستمی حیساباتی کارەبای صالح',

];
