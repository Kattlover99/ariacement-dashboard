<?php

return [

    'recurring'             => 'دووبارەبوونەوە',
    'every'                 => 'هەموو',
    'period'                => 'ماوە',
    'times'                 => 'کات',
    'daily'                 => 'رۆژانە',
    'weekly'                => 'هەفتانە',
    'monthly'               => 'مانگانە',
    'yearly'                => 'ساڵانە',
    'custom'                => 'ئاسایی',
    'days'                  => 'ڕۆژ(ەکان)',
    'weeks'                 => 'هەفتە(ەکان)',
    'months'                => 'مانگ(ەکان)',
    'years'                 => 'ساڵ(ەکان)',
    'message'               => 'This is a recurring :type and the next :type will be automatically generated on :date',

];
