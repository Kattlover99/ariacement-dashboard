<?php

return [

    'previous'              => 'پێشتر',
    'next'                  => 'دواتر',
    'showing'               => ':first-:last of :total records.',
    'page'                  => 'per page.',

];
