<?php

return [

    'total_income'              => 'کۆی داهات',
    'receivables'               => 'وەرگرەکان',
    'open_invoices'             => 'کردنەوەی وەسڵەکان',
    'overdue_invoices'          => 'وەسڵە دواکەوتوەکان',
    'total_expenses'            => 'کۆی تێچوونەکان',
    'payables'                  => 'پارەپێدەرەکان',
    'open_bills'                => 'کردنەوەی پسولەکان',
    'overdue_bills'             => 'پسولە دواکەوتووەکان',
    'total_profit'              => 'کۆی قازانج',
    'open_profit'               => 'قازانج بکەوە',
    'overdue_profit'            => 'قازانجی دواکەوتوو',
    'cash_flow'                 => 'کاش',
    'no_profit_loss'            => 'No Profit Loss',
    'income_by_category'        => 'داهات بەپێی پۆلێن',
    'expenses_by_category'      => 'Expenses By Category',
    'account_balance'           => 'باڵانسی حیساب',
    'latest_income'             => 'دوایین داهات',
    'latest_expenses'           => 'دوایین تێچوونەکان',
];
