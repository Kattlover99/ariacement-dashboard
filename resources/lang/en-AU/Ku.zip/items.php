<?php

return [

    'sales_price'           => 'نرخی فرۆشتن',
    'purchase_price'        => 'نرخی کرین',

];
